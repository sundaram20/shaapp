<?php
	
	include_once( dirname( __FILE__ ) . '/../class/Database.class.php' );
	$pdo = Database::getInstance()->getPdoObject();
	
	$name = $_POST[ 'name' ];
	$message = $_POST[ 'message' ];
	
	$query =mysqli_query($conn, 'INSERT INTO messages VALUES( \'\', :name, :message )' );
	//$query->execute( array( 'name' => $name, 'message' => $message ) );
	$k=array();
	$k[]= array( 'name' => 'dsd', 'message' =>'sdasdas' );
echo json_encode($k);
?>