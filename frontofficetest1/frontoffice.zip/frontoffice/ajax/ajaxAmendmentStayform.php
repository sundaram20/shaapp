<?php
include_once("../../config/auto_loader.php");
if ($_REQUEST['checkoutExtend_date'] != '') {
    $room_no = $_REQUEST['amend_room_no'] ?? '';
    $order_by_room = $_REQUEST['amend_order_by_room'] ?? '';
    $sql = "SELECT * FROM `".FO_RESERVATIONS."` where `id` = '".addslashes(encryptor('decrypt',$_REQUEST['ext_id']))."'";
    $db->query($sql);
    $row = $db->fetch_object();
    $checkin = date('d-m-Y',strtotime($row->checkin));
    $checkout = $row->checkout;
    $checkoutExtend_date = $_REQUEST['checkoutExtend_date'];

    if (strtotime($checkout) <= strtotime($checkoutExtend_date) && strtotime($checkout) != strtotime($checkoutExtend_date)) {

        $checkout =	date('d-m-Y',strtotime($row->checkout));
        $checkoutExtend_date = date('d-m-Y',strtotime($_REQUEST['checkoutExtend_date']));
        $sqlOrderDetail = mysqli_query($connNew,"Select  max(dated) as maxdate,max(id) as maxid from `".FO_RESERVATIONS_DETAILS."` where   id_fo_reservations='".$row->id."' and id_mst_room_no_allocation = '".$room_no."' and order_by_room = '".$order_by_room."'");
        $rowOrderDetail = mysqli_fetch_object($sqlOrderDetail);

        $startTimeStamp = strtotime($rowOrderDetail->maxdate);
        $endTimeStamp = strtotime($checkoutExtend_date);
        $timeDiff = abs($endTimeStamp - $startTimeStamp);
        $numberDays = $timeDiff/86400;
        $numberDays = intval($numberDays);
        $numberDays = $numberDays;
        $check_in = date('Y-m-d', strtotime( $rowOrderDetail->maxdate . " + 1 days"));
        for ($i = 1; $i < $numberDays; $i++) {
            mysqli_query($connNew, "INSERT INTO `fo_reservations_details` ( `id_fo_reservations`, `id_shop`, `id_mst_hotels`, `id_mst_guest`, `id_mst_room_no_allocation`, `plan`, `id_rate`, `id_fo_rate_plan`, `dated`, `id_mst_room_types`, `room_quantity`, `adults_per_room`, `child_without_bed`, `extra_bed_price_per_day_per_room`, `tariff_price_per_day_per_room`, `food_price_per_day_per_room`, `tax_per_day_per_room`, `unique_code`, `id_fo_bill`, `checkin_status`, `id_fo_folio`, `id_fo_folio_to`, `order_by_room`) SELECT  `id_fo_reservations`, `id_shop`, `id_mst_hotels`, `id_mst_guest`, `id_mst_room_no_allocation`, `plan`, `id_rate`, `id_fo_rate_plan`, '".$check_in."', `id_mst_room_types`, `room_quantity`, `adults_per_room`, `child_without_bed`, `extra_bed_price_per_day_per_room`, `tariff_price_per_day_per_room`, `food_price_per_day_per_room`, `tax_per_day_per_room`, `unique_code`, `id_fo_bill`, `checkin_status`, `id_fo_folio`, `id_fo_folio_to`, `order_by_room` FROM `fo_reservations_details` WHERE id='".$rowOrderDetail->maxid."'");
            $check_in = date('Y-m-d', strtotime( $check_in . " + 1 days"));
        }

        $sqlOrderDetailSum = mysqli_query($connNew,"Select  sum(tariff_price_per_day_per_room) as tariff_price_per_day_per_room, sum(tax_per_day_per_room) as tax_per_day_per_room
        from `".FO_RESERVATIONS_DETAILS."` where   id_fo_reservations='".$row->id."'");
        $rowOrderDetailSum= mysqli_fetch_object($sqlOrderDetailSum);

        $insertGrid = "UPDATE `".FO_RESERVATIONS."` SET  
        `checkout`='".date('Y-m-d', strtotime( $_REQUEST['checkoutExtend_date']))."', 
        `sub_total`='".$rowOrderDetailSum->tariff_price_per_day_per_room."',					
        `total_tax`='".$rowOrderDetailSum->tax_per_day_per_room."',						
        `net_booking_amount`='".($rowOrderDetailSum->tariff_price_per_day_per_room+$rowOrderDetailSum->tax_per_day_per_room)."',				
        `balance`='".($rowOrderDetailSum->tariff_price_per_day_per_room+$rowOrderDetailSum->tax_per_day_per_room)."',
        `last_modified` = '".currenDateTime()."',
        `last_modified_by` = '".$_SESSION['userId']."'  where id='".addslashes(encryptor('decrypt',$_REQUEST['ext_id']))."'";
        mysqli_query($connNew,$insertGrid);
        echo 'As per the new checkout Date tariff will be added on these dates.';
    } elseif (strtotime($checkout)>=strtotime($checkoutExtend_date)  && strtotime($checkout)!=strtotime($checkoutExtend_date)) {
        echo 'Remove Date';
        $checkout = date('d-m-Y',strtotime($row->checkout));
        $checkoutExtend_date = date('d-m-Y',strtotime($_REQUEST['checkoutExtend_date']));

        $startTimeStamp = strtotime($checkoutExtend_date);
        $endTimeStamp = strtotime($checkout);
        $timeDiff = abs($endTimeStamp - $startTimeStamp);
        $numberDays = $timeDiff/86400; 
        $numberDays = intval($numberDays);
        $numberDays = $numberDays;
        $check_in = date('Y-m-d', strtotime($checkoutExtend_date));
        for ($i = 0; $i < $numberDays; $i++) {
            mysqli_query($connNew,"DELETE from `".FO_RESERVATIONS_DETAILS."` where `dated`='".date('Y-m-d', strtotime($check_in))."' and `id_fo_reservations`='".addslashes(encryptor('decrypt',$_REQUEST['ext_id']))."'");
            $check_in = date('Y-m-d', strtotime( $check_in . " + 1 days"));
        }

        $sqlOrderDetailSum = mysqli_query($connNew,"Select  sum(tariff_price_per_day_per_room) as tariff_price_per_day_per_room, sum(tax_per_day_per_room) as tax_per_day_per_room
        from `".FO_RESERVATIONS_DETAILS."` where   id_fo_reservations='".addslashes(encryptor('decrypt',$_REQUEST['ext_id']))."'");
        $rowOrderDetailSum = mysqli_fetch_object($sqlOrderDetailSum);

        $insertGrid = "UPDATE `".FO_RESERVATIONS."` SET 
        `checkout`='".date('Y-m-d', strtotime( $_REQUEST['checkoutExtend_date']))."',   
        `sub_total`='".$rowOrderDetailSum->tariff_price_per_day_per_room."',
        `total_tax`='".$rowOrderDetailSum->tax_per_day_per_room."',						
        `net_booking_amount`='".($rowOrderDetailSum->tariff_price_per_day_per_room+$rowOrderDetailSum->tax_per_day_per_room)."',				
        `balance`='".($rowOrderDetailSum->tariff_price_per_day_per_room+$rowOrderDetailSum->tax_per_day_per_room)."',
        `last_modified` = '".currenDateTime()."',
        `last_modified_by` = '".$_SESSION['userId']."'  where id='".addslashes(encryptor('decrypt',$_REQUEST['ext_id']))."'";
        mysqli_query($connNew,$insertGrid);	
        echo 'As per the new checkout Date tariff will be removed on these dates.';
    } else {
        echo 'Please Check Checkout Date'; 
    }
} else {
	echo 'Please Select Checkout Date'; 
}
?>