
/*
var headerFour = document.getElementById("MyStewardSelect");

var btnsFour = headerFour.getElementsByClassName("noofpaxbtn");

for (var j = 0; j < btnsFour.length; j++) {

  btnsFour[j].addEventListener("click", function() {

  var currentFour = document.getElementsByClassName("activestewardbtn");

  if (currentFour.length > 0) { 

    currentFour[0].className = currentFour[0].className.replace(" activestewardbtn", "");

  }

  this.className += " activestewardbtn";

  });

}





var headerThree = document.getElementById("MyNumOfPax");



var btnsThree = headerThree.getElementsByClassName("noofpaxbtn");

for (var j = 0; j < btnsThree.length; j++) {

  btnsThree[j].addEventListener("click", function() {

	  

  var currentThree = document.getElementsByClassName("activenoofpaxbtn");

    

  if (currentThree.length > 0) { 

    currentThree[0].className = currentThree[0].className.replace(" activenoofpaxbtn", "");

  }

  this.className += " activenoofpaxbtn";

  });

}

*/



var headerTwo = document.getElementById("TableListview");

var btnsTwo = headerTwo.getElementsByClassName("tableviewbtn");

for (var j = 0; j < btnsTwo.length; j++) {

  btnsTwo[j].addEventListener("click", function() {

  var currentTwo = document.getElementsByClassName("activetableviewbtn");

  if (currentTwo.length > 0) { 

    currentTwo[0].className = currentTwo[0].className.replace(" activetableviewbtn", "");

  }

  this.className += " activetableviewbtn";

  });

}





var headerOne = document.getElementById("MyTableGroupID");

var btnsOne = headerOne.getElementsByClassName("tablegroupbtn");

for (var j = 0; j < btnsOne.length; j++) {

  btnsOne[j].addEventListener("click", function() {

  var current1 = document.getElementsByClassName("activetablegroup");

  if (current1.length > 0) { 

    current1[0].className = current1[0].className.replace(" activetablegroup", "");

  }

  this.className += " activetablegroup";

  });

}





var header = document.getElementById("MainMenuID");

var btns = header.getElementsByClassName("mainmenu_btn");

for (var i = 0; i < btns.length; i++) {

  btns[i].addEventListener("click", function() {

  var current = document.getElementsByClassName("activeset");  

  if (current.length > 0) { 

    current[0].className = current[0].className.replace(" activeset", "");

  }

  this.className += " activeset";

  });

}



function myFunction() {

	var x = document.getElementById("myDIV");

	var clickButton = document.getElementById('HideOpen');





  if (x.style.display === "none") {

	  

	  clickButton.innerHTML = 'Hide Table ';

    x.style.display = "block";

	

  } else {

	  clickButton.innerHTML = 'Show Table ';

	 

    x.style.display = "none";

	

  }

}

 function TabeleSelect(Selectname)

	  {  

	resultArrayTableID = Selectname.split('_');

	$( "#id_attribute_table" ).val(resultArrayTableID[1]);

	$( "#ViewSelectedTable1" ).html(resultArrayTableID[2]);

  }

function SelectSteward(Steward)

	  {  

	resultArrayStewardID = Steward.split('_');

	$( "#id_attribute_steward" ).val(resultArrayStewardID[0]);
	$( "#attribute_steward_name" ).val(resultArrayStewardID[1]);

	$( "#ViewSteward1" ).html(resultArrayStewardID[1]);

  }  

  

function SelectNoPaxs(Selectpax)

  {  

	$( "#pax" ).val(Selectpax);

	$( "#ViewSelectedPax1" ).html(Selectpax);

  	}

	

function SelectshiftType(SelectshiftType)
  {  

  resultArrayStewardID = Steward.split('_');

  alert(SelectshiftType);

	//$( "#pax" ).val(SelectshiftType);

	

  	}	 

  	  

 function getsubgrouplist(selectmaingroup){	

 

		resultArrayMainGroupId = selectmaingroup.split('_');

		

		$.ajax({

		   type: "POST",

		   url: 'ajax/ajaxGetSubGroup.php',

		   data: 'selectmaingroup='+resultArrayMainGroupId[1]+'&listsubgroup=1', 

		   success: function (result) {			  	    

				$( "#listsubgroup" ).html(result);

				

			}

		})

}	

function getItemlist(selectitemlist){		

	resultArraySubGroupId = selectitemlist.split('_');



		$.ajax({

		   type: "POST",

		   url: 'ajax/ajaxGetSubGroup.php',

		   data: 'selectSubgroup='+resultArraySubGroupId[1]+'&listsubgroup=2', 

		   success: function (result) {			  	    

				$( "#listitemName" ).html(result);

				

			}

		})

}

function keysearch(keyword){

	$.ajax({

		   type: "POST",

		   url: 'ajax/ajaxGetSubGroup.php',

		   data: 'keywordsearch='+keyword+'&listsubgroup=5', 

		   success: function (result) {			  	    
				$( "#SearchResult" ).html(result);
			}

		})

	}

function AddgetItemlist(addItemList,UniqueCodeGen){
	resultArrayItemlistId = addItemList.split('_');
	$('#'+addItemList).not(this).removeClass();
	$('#'+addItemList).toggleClass('btn btn-success');
		$.ajax({
		   type: "POST",
		   url: 'ajax/ajaxGetSubGroup.php',
		   data: 'selectSubgroup='+resultArrayItemlistId[1]+'&listsubgroup=3&UniqueCodeGen='+UniqueCodeGen, 
		   success: function (result) {	
				$( "#GetItemListView" ).html(result);
			}
		})
}



function ajaxRemoveAllItemList(remove){
	
		$.ajax({

			   type: "GET",
			   url: 'ajax/ajaxGetSubGroup.php',
			   data: 'remove='+remove+'&listsubgroup=8', 
			    success: function (result) {	 
				  $( "#GetItemListView" ).html(result);
				}
		})
	}
function ajaxRemoveItemList(uniqueCode,remove){
		$.ajax({

			   type: "GET",

			   url: 'ajax/ajaxGetSubGroup.php',

			   data: 'remove='+remove+'&uniqueCode='+uniqueCode+'&OrderUniqueID='+uniqueCode+'&listsubgroup=3', 

 success: function (result) {

resultArrayItemlistId = result.split('__________');	

	 $( "#GetItemListView" ).html(resultArrayItemlistId[0]);
	 //$( "#listitemName" ).html(resultArrayItemlistId[1]);

	 }

		});

}


function ajaxRemoveEditItemList(uniqueCode,remove,id_pos_purch){
	
		$.ajax({

			   type: "GET",

			   url: 'ajax/ajaxGetSubGroup.php',

			   data: 'remove='+remove+'&uniqueCode='+uniqueCode+'&OrderUniqueID='+uniqueCode+'&listsubgroup=11&id_pos_purch='+id_pos_purch, 

 success: function (result) {

resultArrayItemlistId = result.split('__________');	

	 $( "#GetItemListViewEdit" ).html(resultArrayItemlistId[0]);

	 $( "#listitemName" ).html(resultArrayItemlistId[1]);

	 }

		});

}

function calculateQuantityPriceEdit(uniqueCode,set,quantity,id_pos_purch,UniqueCodeGen){

			if(set==1)	{

			var quantity2 = quantity+1; }

			if(set==0){

			var quantity2 = quantity-1;

			if(quantity2==0){

			var quantity2 = 1;

			}}

			if(set==2){

			var quantity2 = quantity;

			}



	$('#quantity\\|'+uniqueCode).val(quantity2);

	//var OrderUniqueID = $("#OrderUniqueID").val();

	$.ajax({

		   type: "POST",

		   url: 'ajax/ajaxGetSubGroup.php',

		   data: 'selecteduniqueCode='+uniqueCode+'&listsubgroup=10&quantity='+quantity2+'&id_pos_purch='+id_pos_purch+'&UniqueCodeGen='+UniqueCodeGen, 

		   success: function (result) {

				$( "#GetItemListViewEdit" ).html(result);

			}

		})

}

function calculateQuantityPrice(uniqueCode,set,quantity){

			if(set==1)	{

			var quantity2 = quantity+1; }

			if(set==0){

			var quantity2 = quantity-1;

			if(quantity2==0){

			var quantity2 = 1;

			}}

			if(set==2){

			var quantity2 = quantity;

			}



	$('#quantity\\|'+uniqueCode).val(quantity2);

	//var OrderUniqueID = $("#OrderUniqueID").val();

	$.ajax({

		   type: "POST",

		   url: 'ajax/ajaxGetSubGroup.php',

		   data: 'selecteduniqueCode='+uniqueCode+'&listsubgroup=4&quantity='+quantity2, 

		   success: function (result) {
				$( "#GetItemListView" ).html(result);
			}

		})

}	

function getTable(table_group){

	resultArrayItemlistId = table_group.split('_');

	$('#id_attribute_table_group').val(resultArrayItemlistId[1]);

	$('#id_attribute_table').val('');

	$('#ViewSelectedTable1').html('');

	$.ajax({

		type: "GET",

		url: 'ajax/ajaxGetTable.php',

		data: 'table_group='+resultArrayItemlistId[1], 

		success: function (result) {

				$('#id_table').empty();

				$( "#ViewSelectedTable" ).val('');

				$( "#ViewSelectedTable1" ).html('');

				$( "#id_table" ).html(result);

	 	}

	});

}  



function getPreviousOrder(posid){

	//alert('posid='+posid);

	$.ajax({

		type: "GET",

		url: 'ajax/ajaxGetSubGroup.php',

		data: 'posid='+posid+'&listsubgroup=6', 

		success: function (result) {

			//alert(result);				

				$( "#ViewPreviousOrder" ).html(result);

	 	}

	});

} 

function ajaxCancelKot(id){

var form=$("#Formkotremarks");	
	var id_pos_pos_purch_idpurch=$("#pos_purch_id").val();
	//var id_pos_purch=$("#id_pos_purch").val();
	
	if(pos_purch_id!='' && pos_purch_id==undefined){
		var purch = form.serialize()+'&pos_purch_id='+pos_purch_id;
		var saveType='edit';
		
	}else{
		var purch = form.serialize();
		var saveType='add';
		
	}
	$('.loading').show();
    if(form.parsley().validate()){

		$.ajax({
			type: "GET",
			url: 'ajax/ajaxCancelKot.php',
			data: purch, 
			success: function (result) {
			        console.log(result);
			        data = JSON.parse(result);
			
					//$( "#GetItemListView" ).html('');
					getPreviousOrder(data.purch_id);	
					alert(data.msg);
					
					window.location.href='manageKot.php';
      	}

		});

	}
}


function ajaxUpdateKot(id,UniqueCodeGen){
	//alert(id);
	var form=$("#FormPosKot");	
	var id_pos_purch=$("#id_pos_purch").val();
	//var id_pos_purch=$("#id_pos_purch").val();
	
	if(id_pos_purch!='' && id_pos_purch==undefined){
		var purch = form.serialize()+'&id_pos_purch='+id_pos_purch+'&UniqueCodeGen='+UniqueCodeGen;
		var saveType='edit';
		
	}else{
		var purch = form.serialize()+'&UniqueCodeGen='+UniqueCodeGen;
		var saveType='add';
		
	}
	var id_attribute_steward=$("#id_attribute_steward").val();
	var id_attribute_shift=$("#id_attribute_shift").val();
	var pax=$("#pax").val();
	if(pax==''){
		alert('Please select Pax');
		//exit;
	}
	if(id_attribute_shift==''){
		alert('Please select Shift');
		//exit;
	}
	if(id_attribute_steward==''){
		alert('Please select Steward');
		//exit;
	}
	
	
	$('.loading').show();
    if(form.parsley().validate()){

		$.ajax({
			type: "GET",
			url: 'ajax/ajaxUpdateKot.php',
			data: purch, 
			success: function (result) {
			       // console.log(result);
			        //alert(result);
			       var data = JSON.parse(result);
				
					//$( "#GetItemListView" ).html('');
					getPreviousOrder(data.purch_id);	
					alert(data.msg);
					if(saveType=='edit'){
      				window.location.href='managePosKot.php';
					}else{
					window.location.href='manageKot.php';
					}
			}

		});

	}

}
function editKOT(id_pos_purch,UniqueCodeGen){	
	$.ajax({
		type:"POST",
		url: 'ajax/ajaxGetSubGroup.php',
		data: 'listsubgroup=9&id_pos_purch='+id_pos_purch+'&UniqueCodeGen='+UniqueCodeGen, 
		success: function (result) {
		$( "#GetItemListViewEdit" ).html(result);	
			
		 }
		
		})
	
	}
function ViewCancelledKOT(id_pos_purch){
	$.ajax({
		type:"POST",
		url: 'ajax/ajaxGetSubGroup.php',

		data: 'listsubgroup=13&id_pos_purch='+id_pos_purch, 

		success: function (result) {
						
		$( "#GetItemListView" ).html(result);
			
			
		 }
		
		})
	
	}
	
		
function editViewKOT(id_pos_purch){
	$.ajax({
		type:"POST",
		url: 'ajax/ajaxGetSubGroup.php',

		data: 'listsubgroup=12&id_pos_purch='+id_pos_purch, 

		success: function (result) {
						
		$( "#GetItemListView" ).html(result);	
			
		 }
		
		})
	
	}	

function PreviousOrderPax(id_attribute_table){

	//alert(id_attribute_table);

	id_attribute_table = id_attribute_table.split('_');

	$.ajax({

		type: "POST",

		url: 'ajax/ajaxGetSubGroup.php',

		data: 'id_attribute_table='+id_attribute_table[1]+'&listsubgroup=6', 

		success: function (result) {

			//alert(result);

			resulthtml = result.split('EXPLODE');
				$( "#PreviousPaxsID" ).html(resulthtml[0]);
				resultpaxandsteward = resulthtml[1].split('_');				
				$( "#attribute_steward_name" ).val(resultpaxandsteward[3]);
				$( "#id_attribute_steward" ).val(resultpaxandsteward[2]);
				$( "#ViewSteward1" ).html(resultpaxandsteward[3]);

				$( "#pax" ).val(resultpaxandsteward[0]);

				$( "#ViewSelectedPax1" ).html(resultpaxandsteward[0]);

  	

				

				

	 	}

	});

	}

function PreviousOrder(id_attribute_table){

	//alert(id_attribute_table);

	id_attribute_table = id_attribute_table.split('_');

	$.ajax({

		type: "POST",

		url: 'ajax/ajaxGetSubGroup.php',

		data: 'id_attribute_table='+id_attribute_table[1]+'&listsubgroup=7', 

		success: function (result) {

			//alert(result);

			//resulthtml = result.split('EXPLODE');

			//alert(resulthtml[0]);			

				$( "#ViewPreviousOrder" ).html(result);

				//$( "#ViewPreviousOrder" ).html(result);


	 	}

	});

	}	

