<?php include_once("../../config/auto_loader.php");

?>

<script>var headerTwo = document.getElementById("TableListview");

var btnsTwo = headerTwo.getElementsByClassName("tableviewbtn");

for (var j = 0; j < btnsTwo.length; j++) {

  btnsTwo[j].addEventListener("click", function() {

  var currentTwo = document.getElementsByClassName("activetableviewbtn");



  if (currentTwo.length > 0) { 

    currentTwo[0].className = currentTwo[0].className.replace(" activetableviewbtn", "");

  }

  this.className += " activetableviewbtn";

  });

}	

</script>

<?php

		$table_group=$_REQUEST['table_group'];


 					$Resultdoc_type=array();

					  $CheckBlockedTable_Sql_1 = "SELECT id_attribute_table,doc_type FROM pos_purch WHERE pos_bill_type='1' AND doc_type!='24' AND id IN (SELECT id_pos_purch as posid FROM pos_purch_details WHERE qty-adj_qty>0) and doc_type='".$_SESSION['id_document']."'";

	                   $db->query($CheckBlockedTable_Sql_1); 

	                  while($ResultBlockedtable1_1 = $db->fetch_object()){ 	                  	
						$Resultdoc_type[]	=	$ResultBlockedtable1_1->id_attribute_table;
						  }


 $CheckBlockedTable_Sql = "SELECT id_attribute_table FROM pos_purch WHERE pos_bill_type='1' and cancelled=0 AND doc_type!='24' AND id IN (SELECT id_pos_purch as posid FROM pos_purch_details WHERE qty-adj_qty>0)";

	                   $db->query($CheckBlockedTable_Sql); 
                     $ResultBlockedtable=array();
	                  while($ResultBlockedtable1 = $db->fetch_object()){; 

                      array_push($ResultBlockedtable,$ResultBlockedtable1->id_attribute_table);
	                  }



$resContact = selectSql(TBL_ATTRIBUTES," where id_shop='".$_SESSION['shop']."'  AND id_table_group='".$table_group."' AND  status = '1' AND table_name ='".'table'."' ",' 
ORDER BY LPAD(lower(`field_value`),6,0) ');

if($db->num_rows2($resContact) > 0){
	

	?>



               <div class="col-md-12 mt-10">

          

         <div class="form-group">

		 <label class="tablelabel" for="name">Table <font color="#FF0000">*</font> </label>

   

			<form name="listingForm" action="" method="post">

              

            <!-- /.box-header -->

            <div class="box-body table-responsive" style="padding-left: 0px;padding-top: 0px;padding-right: 3px;">

<div id="TableListview">

            	<table id="myTableTest" class="table table-fixed table-striped table-bordered dataTable no-footer" cellspacing="0"  >

		      

		        <tbody>  <?php	

	$i=1;

		while($rowContact = $db->fetch_object2($resContact)){

			

						

    if($i==1){?>

                      <tr>

                       <?php } 

       if (in_array($rowContact->id, $ResultBlockedtable))
 		{
			if (in_array($rowContact->id, $Resultdoc_type)){
	  ?>

       <td style="" class="btn tableviewBlockedbtn" onclick="TabeleSelect(this.id); PreviousOrderPax(this.id);PreviousOrder(this.id);" id="TableGroup_<?php echo $rowContact->id ?>_<?php echo $rowContact->field_value;?>"><?php echo $rowContact->field_value;?></td>

       <?php }else{ ?>
	   <td style=" background-color:#c6574b;" class="btn tableviewBlockedbtn"   id="TableGroup_<?php echo $rowContact->id ?>_<?php echo $rowContact->field_value;?>"><?php echo $rowContact->field_value;?></td>

	  
	  <?php }
  

   }

else

  { ?>

 <td style="" class="btn tableviewbtn" onclick="TabeleSelect(this.id); PreviousOrderPax(this.id);PreviousOrder(this.id);" id="TableGroup_<?php echo $rowContact->id ?>_<?php echo $rowContact->field_value;?>"><?php echo $rowContact->field_value;?></td>

  <?php }

                      ?>  

                               

                            <?php if($i==5){ $i=1;?>   

                               </tr>

                             <?php }else{ $i++; } ?>                 

			<?php

														

																										

		}?>

		

								  

                </tbody>

                

                </table>

                </div></div>

                

                </form>

                </div></div>

                

                

               

        <?php

			}else{?>

				<div class="col-md-5">

          

            <div class="form-group">

		 <label for="name">Table <font color="#FF0000">*</font> </label>

            

			<form name="listingForm" action="" method="post">

              

            <!-- /.box-header -->

            <div class="box-body table-responsive" style="padding:0px;">



            	<table id="myTableTest" class="table table-fixed table-striped table-bordered dataTabletest no-footer" cellspacing="0"  >

		       

		        <tbody>

                <tr><td style="width:100%;">

                No data Available </td>

                </tr>

                </tbody>

                

                </table>

                </div>

                

                </form>

                </div></div>

				<?php }

?>