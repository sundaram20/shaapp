<div id="kdstableview"><div class="col-md-10 col-sm-10 kw-leftbar">
<?php  if($numRows==0){ ?><div style="text-align:center;"><?php echo 'No Record Found.';?></div><?php }?>
<input  type="hidden" name="id_mst_items" id="id_mst_items" value="<?php echo $_REQUEST['id_mst_items'];?>"
					<?php
						//	debugData($itemlistArray);
							// debugData($pendingKotArray);
							 //debugData($listPrintArray);
							foreach($pendingKotArray as $TableDetails2){ 
							foreach($TableDetails2 as $Table=>$TableDetails){ 
							
							
						?>			  
			  
		        	 	<!--tab col starts-->
						<div class="col-md-2  col-sm-2 kw-con">
						  <div class="tab-container">
						    <div class="tabbox">
						      <div class="tabheading" id="checkcont">
						        <div class=" d-flex">
							          <div class="tbsteward">
								            <div class="statusbox">
									           <!-- <div class="d-flex ">
									            	<h4><button class="kotwiseModal"  id="kwstatus" ><?php echo $row->kot_status; ?></button></h4>
									            	<input type="hidden" id="pos_id" value="<?php echo $row->id; ?>"> 
												</div>-->
								            </div>
								            <h4 TITLE="Table"><?php echo $TableDetails['table_name']; ?></h4> <h4 title="Time"><?php echo $TableDetails['time']; ?></h4>     
							          </div>
						         </div>        
						      </div>
						      <!--table heading ends-->
						      <div class="tabcontent" id="kwbox" > 
						        <table class="table table-responsive table table-striped table-bordered dataTable no-footer songs-table">
									<thead style="display:none;">
										<tr>
										  <th>  Items Name</th>
										  <th style="width:10%;"> Qty </th>
										</tr>
									</thead>
									<tbody>
										<?php
											$checkBoxServedStatus='';
										foreach($TableDetails['item'] as $value){
											
											 if($value['checkBoxServed']==1){
											 $checkBoxServedStatus=1;
										 }
											
												$qty = (int)$value['qty'];
												$check_orderis_ready = $value['check_orderis_ready'];
											$old_qty = $value['old_qty'];
										 //  debugData($TableData);
?>
<tr>
											<td><span><?php echo (int)$value['tot_qty'].'x'; ?> </span>&nbsp; <?php echo ucwords(strtolower($value['item_description'])); ?> <div class="itemRemarksLabel"><?php echo $value['special_request_name']; ?></div>
												</td>
								            
											<td style="width:50px;">
												<label class="switchCheck">
													<input type="checkbox" <?php echo $value['checked']; ?>  <?php echo $disabled; ?>class="check_class" value="" id="detail_status-<?php echo $value['id_pos_purch_details']; ?>" name="detail_status" onclick="ChangeCookStatus(this.id,<?php echo $value['tot_qty']; ?>,<?php echo $value['old_qty']; ?>)"><span class="slider round"></span>
													<input type="hidden"  value="<?php echo $value['id_pos_purch_details']; ?>" class="check">
												</label>
											</td></tr>
<?php
											  } ?>		
										
									</tbody>
						        </table>
						      </div>

						      <!--tabcontent ends-->
						        <div class="tabheading" id="checkcont2">
						        <div class=" d-flex" id="checkboxs">
						          <div class="tbsteward">
						            <h4 title="Steward"><?php echo $TableDetails['steward_name']; ?></h4> <h4 title="KOT"><?php echo '#'.$TableDetails['mdoc_no']; ?></h4>   
						          </div>
						         
						          <div class="tbname d-flex" style="margin:4px 14px 4px 4px;align-items:center;">
                                  
			  <input type="checkbox" name="serve_status" <?php echo $TableDetails['checkServedStatus']; ?> id="serve_status_<?php echo $TableDetails['mdoc_no']; ?>_<?php echo $Table; ?>" onClick="CheckServerStatus('<?php echo $TableDetails['mdoc_no']; ?>','<?php echo $TableDetails['id_pos_purch']; ?>','<?php echo $Table; ?>');"  > &nbsp;<?php echo $ServedText; ?>
              
						          </div>

						          </div>
						         
						      </div>
						      <!--table heading ends-->
						    </div>
						  </div>
						</div>
			        	<!--tab col ends-->
							<?php  } } //echo "select "; ?>	
	        	</div>
                </div>

               <!--modal for Served-->
               <!-- Button trigger modal -->
				<!--<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
				  Launch demo modal
				</button>-->

				<!-- Modal -->
				<div class="modal" id="servedModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				  <div class="modal-dialog" role="document">
				    <div class="modal-content">
				      <div class="">
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				       <input type="hidden" name="mdoc_no_new" id="mdoc_no_new" value="" />
                       <input type="hidden" name="id_new" id="id_new" value="" />
                       <input type="hidden" name="id_mst_outlet_new" id="id_mst_outlet_new" value="" />
                       <input type="hidden" name="ServerStatusWithoutCook" id="ServerStatusWithoutCook" value="0" />
<input type="hidden" name="ServerStatus" id="ServerStatus" value="<?php echo $servestatus;?>" />
                       
                       
				      </div>
				      <div class="modal-body">
				       <p> One Or More items are  not Ready !!<br><br>

				        Still do  you want to continue ? </p>
				      </div>
				      <div class="modal-footer">
				      	 <button type="button" class="btn  o-btn" onclick="CheckServerStatusWithoutCook();">Yes</button>
				        <button type="button" class="btn o-btn" data-dismiss="modal">No</button>
				       
				      </div>
				    </div>
				  </div>
				</div>